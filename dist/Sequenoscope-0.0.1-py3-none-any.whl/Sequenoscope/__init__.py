#!/usr/bin/env python

from version import __version__
import sequenoscope