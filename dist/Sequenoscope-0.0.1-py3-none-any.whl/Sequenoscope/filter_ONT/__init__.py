#!/usr/bin/env python

from filter_ONT.seq_summary_processing import SeqSummaryProcesser
from filter_ONT.seqtk import SeqtkRunner
from utils.sequence_class import Sequence